cmd_arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dtb := /home/aum/aarch64-linux-android-4.9/bin/aarch64-linux-android-gcc -E -Wp,-MD,arch/arm64/boot/dts/.exynos7870-on7xreflte_swa_open_00.dtb.d.pre.tmp -nostdinc -I./arch/arm64/boot/dts -I./arch/arm64/boot/dts/include -I./include -I./drivers/of/testcase-data -undef -D__DTS__ -DANDROID_VERSION=990000 -DANDROID_MAJOR_VERSION= -x assembler-with-cpp -o arch/arm64/boot/dts/.exynos7870-on7xreflte_swa_open_00.dtb.dts.tmp arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dts ; ./scripts/dtc/dtc -O dtb -o arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dtb -b 0 -i arch/arm64/boot/dts/  -d arch/arm64/boot/dts/.exynos7870-on7xreflte_swa_open_00.dtb.d.dtc.tmp arch/arm64/boot/dts/.exynos7870-on7xreflte_swa_open_00.dtb.dts.tmp ; cat arch/arm64/boot/dts/.exynos7870-on7xreflte_swa_open_00.dtb.d.pre.tmp arch/arm64/boot/dts/.exynos7870-on7xreflte_swa_open_00.dtb.d.dtc.tmp > arch/arm64/boot/dts/.exynos7870-on7xreflte_swa_open_00.dtb.d

source_arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dtb := arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dts

deps_arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dtb := \
  arch/arm64/boot/dts/exynos7870-on7xreflte_common.dtsi \
  arch/arm64/boot/dts/exynos7870-rmem-3000MB.dtsi \
  arch/arm64/boot/dts/exynos7870.dtsi \
  include/dt-bindings/clock/exynos7870.h \
  include/dt-bindings/sysmmu/sysmmu.h \
  include/dt-bindings/thermal/thermal.h \
  arch/arm64/boot/dts/exynos7870-pinctrl.dtsi \
  arch/arm64/boot/dts/exynos7870-busmon.dtsi \
  arch/arm64/boot/dts/modem-ss315ap-pdata.dtsi \
  arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_gpio_00.dtsi \
  arch/arm64/boot/dts/exynos_gpio_config_macros.dtsi \
  arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_battery_00.dtsi \
  arch/arm64/boot/dts/exynos7870-on7xelte_fingerprint-sensor_02.dtsi \

arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dtb: $(deps_arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dtb)

$(deps_arch/arm64/boot/dts/exynos7870-on7xreflte_swa_open_00.dtb):
